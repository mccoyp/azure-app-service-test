# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
from ._version import VERSION

SDK_MONIKER = f"keyvault-administration/{VERSION}"
